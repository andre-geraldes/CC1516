ls audiofiles | grep .mp3 > songs.txt
